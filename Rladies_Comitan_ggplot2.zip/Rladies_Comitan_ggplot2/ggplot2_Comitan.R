#!/usr/bin/env Rscript
#  ggplot2_Comitan.R
#  Copyright 2021- E. Ernestina Godoy Lozano (tinagodoy@gmail.com)
#
#  This program is free software; you can redistribute it and/or modify
#  it under the terms of the GNU General Public License as published by
#  the Free Software Foundation; either version 2 of the License, or
#  (at your option) any later version.
#
#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with this program; if not, write to the Free Software
#  Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
#  MA 02110-1301, USA.
#  Texto sin acentos

##################################################
#####        CAPITULO RLADIES COMITAN        #####
#####         Graficando con ggplot2         #####
#####   Ponente: E. Ernestina Godoy Lozano   #####
##################################################

#########################################################
####           Cargar librerias de trabajo           ####
#########################################################

library(ggplot2)
getwd()

#########################################################
####               Ejercicio: qplot()                ####
####             Diapositivas: 16-21                 ####
#########################################################

# Usar datos de vectores numéricos
x <- 1:10
y <- rnorm(10, 4.5, 0.1)

# Explorar datos
x
y

# Plot basico
qplot(x,y)

# Añadir una linea
qplot(x, y, geom=c("point", "line"))

# Usar datos de un data.frame, "abiotic_variables.txt"
# Leer datos
abiotic <- read.delim("tables/abiotic_variables.txt", header=T, row.names=1)

# Explorar los datos
View(abiotic)
dim(abiotic)
summary(abiotic)

qplot(x=Naphthalene, y=Deep, data=abiotic)

# Smoothing (agregar una línea suavizada con su error estandar)
qplot(x=Naphthalene, y=Deep, data = abiotic, geom = c("point", "smooth"))

# Ajuste lineal por grupo
qplot(x=Naphthalene, y=Deep, data = abiotic, color = factor(Class), geom=c("point", "smooth"))

# Cambiar el color por una variable numerica continua
qplot(x=Naphthalene, y=Deep, data = abiotic, colour = Organic_Matter)

# Cambiar el color por grupos (factor)
df <- abiotic
df[,'Class'] <- as.factor(df[,'Class'])
qplot(x=Naphthalene, y=Deep, data = df, colour = Class)

# Añadir lineas
qplot(Naphthalene, Deep, data = df, colour = Class, geom=c("point", "line"))
    
# Adiccion de temas
qplot(Naphthalene, Deep, data = df, colour = Class, geom=c("point", "line")) + 
  theme_bw()  

#########################################################
####               Ejercicio: ggplot()               ####
####             Diapositivas: 25-32                 ####
#########################################################

## Usaremos un set de datos simulado "antibodies". Datos que provienen de pacientes recuperados de Dengue
# Explorar los datos
antibodies <- read.delim("tables/antibodies.txt", header=T)
head(antibodies)
summary(antibodies)
dim(antibodies)

# Agregar datos a un objeto con la funcion ggplot ()
p <- ggplot(data=antibodies)

## Añadir aesthetics
p <- p + aes(x= CDR3.length, y = VJ.identity, colour = V.GENE)

### Otra forma de hacer el codigo anterior en una sola linea

p <- ggplot(data=antibodies, aes(x = CDR3.length, y = VJ.identity, colour = V.GENE))

### Vamos a explorar nuestro objeto "p"
summary(p)

## Agregar capas (layers)
p <- p + geom_point()
p

# Añadiendo transformaciones estadisticas de los datos. En este caso estamos usando una recta ajustada por cuadrados minimos
p <-p + geom_smooth(method="lm")
p

### Hazlo en una linea
ggplot(data=antibodies, aes(x = CDR3.length, y = VJ.identity, colour = V.GENE)) + 
  geom_point() + geom_smooth(method="lm")

## Facet grid (Cuadrícula de facetas)
### Vertical
ggplot(data=antibodies, aes(x = CDR3.length, y = VJ.identity, colour = V.GENE)) + 
  geom_point() + geom_smooth(method="lm") +
  facet_grid(~ V.GENE)

### Horizontal
ggplot(data=antibodies, aes(x = CDR3.length, y = VJ.identity, colour = V.GENE)) + 
  geom_point() + geom_smooth(method="lm") +
  facet_grid(V.GENE ~.)

### Quitar leyenda
ggplot(data=antibodies, aes(x=CDR3.length, y=VJ.identity, colour=V.GENE)) + 
  geom_point(show.legend = FALSE) + geom_smooth(method="lm", show.legend = FALSE) +
  facet_grid(V.GENE~.)

## Cambio de temas
ggplot(data=antibodies, aes(x = CDR3.length, y = VJ.identity, colour = V.GENE)) + 
  geom_point(show.legend = FALSE) + geom_smooth(method="lm", show.legend = FALSE) +
  facet_grid(V.GENE~.) +
  theme_bw()

ggplot(data=antibodies, aes(x = CDR3.length, y = VJ.identity, colour = V.GENE)) + 
  geom_point(show.legend = FALSE) + geom_smooth(method="lm", show.legend = FALSE) +
  facet_grid(V.GENE~.) +
  theme_linedraw()

#  Cambiar otros elementos en el tema
ggplot(data=antibodies, aes(x = CDR3.length, y = VJ.identity, colour = V.GENE)) + 
  geom_point(show.legend = FALSE) + geom_smooth(method="lm", show.legend = FALSE) +
  facet_grid(V.GENE~.) +
  theme_bw() +  
  theme(panel.background = element_rect(fill = "black"), panel.grid.minor = element_line(linetype = "dotted"))

#### Guardar imagenes

# En que directorio me encuentro
getwd()
dir()

# Primera opcion
### PNG con una resolucion de 300 px
png("figures/dot_plot_antibodies_data.png", width=10 *300, height=8*300, res= 300)
ggplot(data=antibodies, aes(x = CDR3.length, y = VJ.identity, colour = V.GENE)) + 
  geom_point(show.legend = FALSE) + 
  facet_grid(V.GENE~.) +
  theme_linedraw()
dev.off()

### PDF (Imagen vectorizada)
pdf("figures/dot_plot_antibodies_data.pdf", width=10, height=8)
ggplot(data=antibodies, aes(x = CDR3.length, y = VJ.identity, colour = V.GENE)) + 
  geom_point(show.legend = FALSE) + 
  facet_grid(V.GENE~.) +
  theme_linedraw()
dev.off()

# Segunda opcion con una funcion propia de ggplot2
ggsave("figures/dot_plot_antibodies_data.jpg", device= "jpg")

#########################################################
####               Ejercicio: Bar plots              ####
####               Diapositivas: 33-36               ####
#########################################################
# data
# library(gcookbook)
### crear datos "cabbage_exp"
# cabbage_exp --> Es el recopilado de un experimento de un cultivo de "Col o repollo (cabbage)". Fueron 2 condiciones C39 y C52; y se cortaron las coles a los dias 16, 20 y 21; se pesaron 10 coles de la condicion y se obtuvo la desviacion estandar y el error estandar de la media del peso.

cabbage_exp <- data.frame(Cultivar=c(rep("c39", 3), rep("c52", 3)), Date=rep(c("d16", "d20", "d21"),2), Weight=c(3.18, 2.80, 2.74, 2.26, 3.11, 1.47), sd= c(0.9566144, 0.2788867, 0.9834181, 0.4452215, 0.7908505, 0.2110819), n=rep(10,6), se=c(0.30250803, 0.08819171, 0.31098410, 0.14079141, 0.25008887, 0.06674995))
# Explorar datos
cabbage_exp

# Grafico de Bar plots basico
ggplot(data= cabbage_exp, aes(x=Date, y= Weight)) + geom_bar(stat="identity")

# Cambio de color de las barras
ggplot(data= cabbage_exp, aes(x=Date, y= Weight)) + geom_bar(stat="identity", fill="dodgerblue")

# Cambio de tema
ggplot(data= cabbage_exp, aes(x=Date, y= Weight)) + geom_bar(stat="identity", fill="dodgerblue") + theme_bw()

### Grafico con barras apiladas coloreado por condicion
ggplot(data= cabbage_exp, aes(x=Date, y=Weight, fill=Cultivar)) + 
	geom_bar(stat="identity", position="dodge")

### Usa otra paleta de colores
ggplot(data= cabbage_exp, aes(x=Date, y=Weight, fill=Cultivar)) + 
	geom_bar(stat="identity", position="dodge") +
	scale_fill_brewer(palette="Set1")

### Añadir texto
ggplot(data= cabbage_exp, aes(x=Date, y=Weight, fill=Cultivar)) + 
	geom_bar(stat="identity") +
	scale_fill_brewer(palette="Set1") +
	geom_text(aes(label=Weight), vjust=1.5)

## Posicion "dodge"
ggplot(data= cabbage_exp, aes(x=Date, y=Weight, fill=Cultivar)) + 
	geom_bar(stat="identity", position="dodge") +
	scale_fill_brewer(palette="Set1") +
	geom_text(aes(label=Weight), vjust=-0.4, position=position_dodge(0.9), size=3, colour="green4")

### Añadir barras de error
ggplot(data= cabbage_exp, aes(x=Date, y=Weight, fill=Cultivar)) + 
	geom_bar(stat="identity", position="dodge") +
	scale_fill_brewer(palette="Set1") +
  geom_errorbar(aes(ymin=Weight-se, ymax=Weight+se), width=0.2, position=position_dodge(0.9)) +
	theme_bw()

#########################################################
####           Ejercicio: Scatter plots              ####
####              Diapositivas: 37-38                ####
#########################################################

# Usaremos de nuevo los datos de antibodies
#### Scatter plots basicos
ggplot(data= antibodies, aes(x= CDR3.length, y= VJ.identity)) +
	geom_point()
	
# Color por condicion
ggplot(data= antibodies, aes(x= CDR3.length, y= VJ.identity, colour=V.GENE)) +
	geom_point()

# Forma por condicion
ggplot(data= antibodies, aes(x= CDR3.length, y= VJ.identity, shape=V.GENE)) +
	geom_point()

# Forma y color por condicion
ggplot(data= antibodies, aes(x= CDR3.length, y= VJ.identity, shape=V.GENE, colour=V.GENE)) +
	geom_point() 

# Cambiar los valores de forma
ggplot(data= antibodies, aes(x= CDR3.length, y= VJ.identity, shape=V.GENE, colour=V.GENE)) +
	geom_point() +
	scale_shape_manual(values=c(1,2,3))

# Cambiar colores manuales
ggplot(data= antibodies, aes(x= CDR3.length, y= VJ.identity, shape=V.GENE, colour=V.GENE)) +
	geom_point() +
	scale_shape_manual(values=c(1,2,3)) +
	scale_colour_manual(values=c("deepskyblue", "seagreen2", "salmon")) +
	theme_bw()

#########################################################
####              Ejercicio: Histograms              ####
####               Diapositivas: 39-41               ####
#########################################################

## Histograma basico
ggplot(data= antibodies, aes(x= VJ.identity)) +
	geom_histogram()

# Elegir un mejor ancho de barra (binwidth)
ggplot(data= antibodies, aes(x= VJ.identity)) +
	geom_histogram(binwidth=0.3)
	
# Divide el rango x en 20 barras (bins)
binsize <- diff(range(antibodies$VJ.identity))/20

# Cambiar el color de las barras
ggplot(data= antibodies, aes(x= VJ.identity)) +
	geom_histogram(binwidth= binsize, colour="black", fill="royalblue4")

# Varios histogramas con diferentes colores de relleno
ggplot(data= antibodies, aes(x= VJ.identity, fill=V.GENE)) +
	geom_histogram(binwidth= binsize, colour="black")
	
# Cambiar el valor de "alpha" (transparencia)
ggplot(data= antibodies, aes(x= VJ.identity, fill=V.GENE)) +
	geom_histogram(binwidth= binsize, position="identity", alpha=0.4)

# Añadir un Density plot -- Plot de Densidad
ggplot(data= antibodies, aes(x= VJ.identity, fill=V.GENE, y= ..density..)) +
	geom_histogram(binwidth= binsize, position="identity", alpha=0.4, colour="gray") +	
	geom_density(alpha=0.4)

# Cambiar la apariencia
ggplot(data= antibodies, aes(x= VJ.identity, fill=V.GENE, y= ..density..)) +
	geom_histogram(binwidth= binsize, position="identity", alpha=0.4, colour="gray") +	
	geom_density(alpha=0.4) + 
	scale_fill_manual(values=c("deepskyblue", "seagreen2", "salmon")) +
	theme_bw()

#########################################################
####               Ejercicio: Boxplots               ####
####               Diapositivas: 42-44               ####
#########################################################

# Boxplot basico
ggplot(data=antibodies, aes(y= V.Nb.mutations, x= V.GENE)) +
	geom_boxplot()

# Con muescas (notch)
ggplot(data=antibodies, aes(y= V.Nb.mutations, x= V.GENE)) +
	geom_boxplot(notch= TRUE)
	
# Cambiar la apariencia
ggplot(data=antibodies, aes(y= V.Nb.mutations, x= V.GENE, fill=V.GENE)) +
	geom_boxplot(notch= TRUE) +
	scale_fill_manual(values=c("deepskyblue", "seagreen2", "salmon")) +
	theme_bw()

## Cambiar las etiquetas de los ejes
ggplot(data=antibodies, aes(y= V.Nb.mutations, x= V.GENE, fill=V.GENE)) +
	geom_boxplot(notch= TRUE) +
	scale_fill_manual(values=c("deepskyblue", "seagreen2", "salmon")) +
	labs (title= " Boxplot V.GENE", y= "VH mutations (nt)", x= "", fill= "") +
	theme_bw()

# Grafico de Violin
ggplot(data=antibodies, aes(y= V.Nb.mutations, x= V.GENE,  fill=V.GENE)) +
	geom_violin() +
	scale_fill_manual(values=c("deepskyblue", "seagreen2", "salmon")) +
	labs (title= " Boxplot V.GENE", y= "VH mutations (nt)", x= "", fill= "") 

# Cambiar la posicion del recuadro de la leyenda
ggplot(data=antibodies, aes(y= V.Nb.mutations, x= V.GENE,  fill=V.GENE)) +
	geom_violin() +
	scale_fill_manual(values=c("deepskyblue", "seagreen2", "salmon")) +
	labs (title= " Boxplot V.GENE", y= "VH mutations (nt)", x= "", fill= "") +
	theme(legend.position="bottom")

####################################################################
####  Ejercicio Extra: Diagramas de caja con ajuste de facetas  ####
####                     Diapositivas: 45-47.                   ####
####################################################################

#### Cargar libreria extra
library(reshape2)
tmp <- melt(iris)

# Explorar los datos ¿Que hace la funcion melt?
head(tmp)
dim(tmp)
summary(tmp)

# boxplot con ajuste de faceta (facet wrap)
ggplot(data= tmp, aes(x= Species, y= value)) +
	geom_boxplot() +
	facet_wrap(~variable)

# Cambiar la apariencia
ggplot(data= tmp, aes(x= Species, y= value, fill= Species)) +
	geom_boxplot() +
	facet_wrap(~variable) +
	scale_fill_manual(values=c("deepskyblue", "seagreen2", "salmon")) +
	labs(y="cm", x="", fill="") +
  theme_linedraw()
