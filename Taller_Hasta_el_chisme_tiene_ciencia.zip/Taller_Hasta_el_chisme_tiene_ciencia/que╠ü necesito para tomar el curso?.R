#3er. encuentro anual de R-ladies México,
#taller:
#  - "Hasta el chisme tiene ciencia", 
# Análisis de frecuecia y texto sobre tus mensajes de Whatsapp en R

# Impartido por: Ameyalli de Jesus Perea Carreto.

# El taller será de una hora en modalidad virtual y previo a este se necesita 
# hacer estos 2 pasos:
####PASO 1. Se requiere que previamente instales estas librerias:
install.packages("rwhatsapp")
library(rwhatsapp)

library(lubridate) 
library(tidyverse) 
library(tidytext) 
library(kableExtra)
library(RColorBrewer)
library(knitr)
#### PASO 2. Exportar el historial del Chat en Whatsapp con tu ser querido, 
#es muy sencillo: Desde tu WhatsApp en cualquier conversación abierta, da clic en el menú de los tres puntos de la parte arriba derecha en Opciones/Más/Exportar chat. e inmediato a esto podrás enviarte el historial completo como archivo de texto con extensión “.txt” a un correo. Preferentemente utiliza la opción sin multimedia, ya que la descarga está restringuida hasta cierta cantidad de información, por lo que, dependediendo de cómo sea tu interacción con la persona podrías ver mensajes de años o apenas de unos meses atrás. Nota: Se debe tener en consideración que para que las gráficas de frecuencia sean más precisas, las pláticas en Whatsapp deberían estar en horario de 24hrs, si tu celular registra la hora con AM y PM, no se verá como en el taller. La dinámica del taller será la siguiente: - Bienvenida - Llamado de las librerias (espacio para dudas, etc). - Gráficas de frecuencias. - Análisis de texto.
# No te lo pierdas! Habrán rifas y regalos para nuestros participantes!
#  Los esperamos este sábado 24 de septiembre del 2022, a las 10 a.m. en formato híbrido multisede.
# Inscripciones y más informes aquí en Meetup!



